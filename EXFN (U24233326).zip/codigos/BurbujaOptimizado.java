import java.util.Arrays;
public class BurbujaOptimizado {

    public static void ordenarBurbujaOptimizado(int[] arreglo) {
        int n = arreglo.length;
        
        // bucle externo
        for (int i = 0; i < n; i++) {
            // bandera de optimización
            boolean huboIntercambio = false;
            
            // bucle interno
            for (int j = 0; j < n - i - 1; j++) {
                if (arreglo[j] > arreglo[j + 1]) {
                    // intercambio
                    int auxiliar = arreglo[j];
                    arreglo[j] = arreglo[j + 1];
                    arreglo[j + 1] = auxiliar;
                    
                    // si hay intercambio, la bandera de optimización cambia a true
                    huboIntercambio = true;
                }
            }
            
            // impresión
            System.out.println("Pasada " + (i + 1) + ": " + Arrays.toString(arreglo));

            // si no hubo intercambio, el arreglo ya está ordenado
            if (!huboIntercambio) {
                System.out.println("\nNo hubo intercambios en la pasada " + (i + 1) + ".");
                break;
            }
        }
    }

    public static void main(String[] args) {
        int[] tiempos = {42, 17, 23, 17, 8, 31, 14, 29};
        
        System.out.println("Arreglo inicial: " + Arrays.toString(tiempos));
        System.out.println("------------------------------------------------");

        // llamado del método burbuja
        ordenarBurbujaOptimizado(tiempos);
        
        System.out.println("------------------------------------------------");
        System.out.println("Arreglo ordenado final: " + Arrays.toString(tiempos));
    }
}