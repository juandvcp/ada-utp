import java.util.Arrays;
public class BusquedaBinariaIterativa {

    public static int buscarBinario(int[] arreglo, int valorBuscado) {
        int inicio = 0;
        int fin = arreglo.length - 1;
        int iteracion = 1;

        System.out.println("Iniciando búsqueda del valor " + valorBuscado + "...");
        System.out.println("----------------------------------------------------------------------");

        while (inicio <= fin) {
            // calculo del medio
            int medio = inicio + (fin - inicio) / 2;
            int valorMedio = arreglo[medio];

            // imprimir traza
            System.out.printf("Iteración %d -> Rango: [%d, %d] | Medio calculado: %d (Valor: %d)%n", 
                              iteracion, inicio, fin, medio, valorMedio);

            // encontrado
            if (valorMedio == valorBuscado) {
                System.out.println("----------------------------------------------------------------------");
                System.out.println("Valor encontrado en el índice: " + medio);
                return medio;
            }

            // el valor buscado es mayor, entonces descarta la mitad izquierda
            if (valorBuscado > valorMedio) {
                System.out.println("    -> " + valorBuscado + " > " + valorMedio + ". Descartando mitad izquierda.");
                inicio = medio + 1;
            } 
            // el valor buscado es menor, entonces descarta la mitad derecha
            else {
                System.out.println("    -> " + valorBuscado + " < " + valorMedio + ". Descartando mitad derecha.");
                fin = medio - 1;
            }

            iteracion++;
            System.out.println();
        }

        System.out.println("----------------------------------------------------------------------");
        System.out.println("El valor " + valorBuscado + " no se encuentra en el arreglo.");
        return -1;
    }

    public static void main(String[] args) {
        int[] datos = {3, 7, 12, 16, 21, 25, 30, 34, 39, 44, 48, 53, 57, 61, 68};
        int valor48 = 48;

        System.out.println("Arreglo ordenado: " + Arrays.toString(datos));
        System.out.println();

        // llamado de la busqueda binaria
        int resultado = buscarBinario(datos, valor48);
    }
}