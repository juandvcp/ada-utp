import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BusquedaSecuencialCoincidencias {

    public static void buscarTodasLasCoincidencias(int[] arreglo, int codigoBuscado) {
        int n = arreglo.length;
        int contador = 0;
        List<Integer> posiciones = new ArrayList<>();

        // Recorrido secuencial paso a paso
        for (int i = 0; i < n; i++) {
            if (arreglo[i] == codigoBuscado) {
                posiciones.add(i); // Guardamos la posición (índice basado en 0)
                contador++;
            }
        }

        // impresion
        System.out.println("Resultados de la búsqueda para el código: " + codigoBuscado);
        System.out.println("----------------------------------------------");
        if (contador > 0) {
            System.out.println("Coincidencias encontradas en los índices: " + posiciones);
            System.out.println("Cantidad total de apariciones: " + contador);
        } else {
            System.out.println("El código no existe.");
        }
    }

    public static void main(String[] args) {
        int[] incidencias = {34, 18, 27, 34, 12, 45, 34, 20, 18, 34};
        int codigoBuscado = 34;

        System.out.println("Arreglo de incidencias: " + Arrays.toString(incidencias));
        System.out.println();
        
        buscarTodasLasCoincidencias(incidencias, codigoBuscado);
    }
}