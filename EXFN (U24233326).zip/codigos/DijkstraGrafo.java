import java.util.*;
public class DijkstraGrafo {

    // clase arista
    static class Arista {
        char destino;
        int peso;

        public Arista(char destino, int peso) {
            this.destino = destino;
            this.peso = peso;
        }
    }

    public static void main(String[] args) {
        // representación del grafo mediante un mapa de adyacencia
        Map<Character, List<Arista>> grafo = new HashMap<>();
        inicializarGrafo(grafo);

        char origen = 'A';
        char destino = 'F';

        // ejecución del algoritmo de Dijkstra
        ejecutarDijkstra(grafo, origen, destino);
    }

    private static void inicializarGrafo(Map<Character, List<Arista>> grafo) {
        for (char nodo : new char[]{'A', 'B', 'C', 'D', 'E', 'F'}) {
            grafo.put(nodo, new ArrayList<>());
        }

        // definición de aristas
        agregarArista(grafo, 'A', 'B', 4);
        agregarArista(grafo, 'A', 'C', 2);
        agregarArista(grafo, 'B', 'C', 1);
        agregarArista(grafo, 'B', 'D', 5);
        agregarArista(grafo, 'C', 'D', 8);
        agregarArista(grafo, 'C', 'E', 10);
        agregarArista(grafo, 'D', 'E', 2);
        agregarArista(grafo, 'D', 'F', 6);
        agregarArista(grafo, 'E', 'F', 3);
    }

    private static void agregarArista(Map<Character, List<Arista>> grafo, char u, char v, int peso) {
        grafo.get(u).add(new Arista(v, peso));
        grafo.get(v).add(new Arista(u, peso));
    }

    public static void ejecutarDijkstra(Map<Character, List<Arista>> grafo, char origen, char destino) {
        // estructuras para distancias, predecesores y estado de visita
        Map<Character, Integer> distancias = new HashMap<>();
        Map<Character, Character> predecesores = new HashMap<>();
        Set<Character> visitados = new HashSet<>();

        // 1. inicialización
        System.out.println("=== Inicialización ===");
        for (char nodo : grafo.keySet()) {
            distancias.put(nodo, Integer.MAX_VALUE); // oo es infinito por si acaso xd
            predecesores.put(nodo, '-');
        }
        distancias.put(origen, 0); // distancia al nodo de origen es 0

        imprimirEstado(distancias, predecesores, visitados);
        System.out.println("=========================\n");

        System.out.println("=== 2. ejec paso a paso ===");
        int iteracion = 1;

        while (visitados.size() < grafo.size()) {
            // Selección del nodo con la menor distancia tentativa no visitado
            char nodoActual = seleccionarNodoMinimo(distancias, visitados);
            if (nodoActual == ' ') break; // No quedan nodos alcanzables

            visitados.add(nodoActual);
            System.out.println("Iteración " + iteracion + ": Seleccionando nodo [" + nodoActual + "]");
            System.out.println("-----------------------------------------");

            // relajación de aristas adyacentes
            for (Arista arista : grafo.get(nodoActual)) {
                char vecino = arista.destino;
                if (!visitados.contains(vecino)) {
                    int pesoArista = arista.peso;
                    int distanciaNueva = distancias.get(nodoActual) + pesoArista;

                    System.out.print("  Evaluando arista " + nodoActual + "-" + vecino + " (peso " + pesoArista + "): ");
                    
                    if (distanciaNueva < distancias.get(vecino)) {
                        System.out.println("RELAJACIÓN -> Nueva dist. de " + vecino + " es " + distanciaNueva + " (Predecesor: " + nodoActual + ")");
                        distancias.put(vecino, distanciaNueva);
                        predecesores.put(vecino, nodoActual);
                    } else {
                        System.out.println("Sin cambio (dist. actual " + (distancias.get(vecino) == Integer.MAX_VALUE ? "oo" : distancias.get(vecino)) + " <= " + distanciaNueva + ")");
                    }
                }
            }

            imprimirEstado(distancias, predecesores, visitados);
            System.out.println();
            iteracion++;
        }

        // camino más corto
        System.out.println("=== Resultado final ===");
        if (distancias.get(destino) == Integer.MAX_VALUE) {
            System.out.println("No existe camino para llegar a " + destino);
        } else {
            List<Character> camino = new ArrayList<>();
            char actual = destino;
            while (actual != '-') {
                camino.add(actual);
                actual = predecesores.get(actual);
            }
            Collections.reverse(camino);

            System.out.print("Camino más corto: ");
            for (int i = 0; i < camino.size(); i++) {
                System.out.print(camino.get(i) + (i < camino.size() - 1 ? " -> " : ""));
            }
            System.out.println("\nDistancia total: " + distancias.get(destino));
        }
    }

    private static char seleccionarNodoMinimo(Map<Character, Integer> distancias, Set<Character> visitados) {
        char nodoMinimo = ' ';
        int minDistancia = Integer.MAX_VALUE;

        for (Map.Entry<Character, Integer> entrada : distancias.entrySet()) {
            char nodo = entrada.getKey();
            int distancia = entrada.getValue();

            if (!visitados.contains(nodo) && distancia < minDistancia) {
                minDistancia = distancia;
                nodoMinimo = nodo;
            }
        }
        return nodoMinimo;
    }

    private static void imprimirEstado(Map<Character, Integer> distancias, Map<Character, Character> predecesores, Set<Character> visitados) {
        System.out.println("  Nodos Visitados: " + visitados);
        System.out.printf("  %-10s | %-15s | %-10s\n", "Nodo", "Dist. Tentativa", "Predecesor");
        System.out.println("  ---------------------------------------------");
        
        // ordenamiento alfabeticamente
        List<Character> nodosOrdenados = new ArrayList<>(distancias.keySet());
        Collections.sort(nodosOrdenados);

        for (char nodo : nodosOrdenados) {
            int dist = distancias.get(nodo);
            String distStr = (dist == Integer.MAX_VALUE) ? "oo" : String.valueOf(dist);
            System.out.printf("  %-10c | %-15s | %-10c\n", nodo, distStr, predecesores.get(nodo));
        }
    }
}